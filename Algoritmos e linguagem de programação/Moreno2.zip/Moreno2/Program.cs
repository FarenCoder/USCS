﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Moreno2
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
            double x, y;
            char l;
            bool resp;
            string nome;
            num = 10;
            x = 24.45;
            y = 754.2;
            l = 'a';
            resp = false;
            nome = "Pedro";
        }
    }
}
