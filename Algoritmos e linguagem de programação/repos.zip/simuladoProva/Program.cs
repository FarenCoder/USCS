﻿using System;

namespace simuladoProva
{
    class Program
    {/*
        static void Main(string[] args)
        {
            
            double c = 5,s = 8;
            while (c >= 1) {
                    c--;
                    s = s + c;
            }
            s = s + c;
            Console.WriteLine(s);
        }
    }
}
*/
     /*
                 double c = 5;
                 double s = 8;

                 if (c == 0)
                 {
                     s = 8;
                     c--;
                     s = s + c;
                     Console.WriteLine(s);
                 }
                 else
                 {
                     s = s + c;
                     Console.WriteLine(s);
                 }

             }
         }
     }*/
     /*
        static void Main(string[] args)
        {
            int A, B,R;
            Console.WriteLine("DIGITE A");
            A = int.Parse(Console.ReadLine());
            Console.WriteLine("DIGITE A");
            B = int.Parse(Console.ReadLine());
            if(A>2)
            {
                if (B > 5)
                {
                    R = A + B;
                    Console.WriteLine(R);
                }

            }
          
        }
        
    }
}
*/
     /*
             static void Main(string[] args)
             {
                 int A, B,C, R1,R2,Q1,Q2,X;
                 A = 10;B = 50;C = 30;
                 Q1 = B / A;
                 Q2 = B / 7;
                 R1 = C % A;
                 R2 = B % C;
                 Console.WriteLine(Q2);

                 if((R1+R2)>=1)
                 {
                     X = Q1 + Q2 + 20;

                 }
                 else
                 {
                     X = Q1 + Q2 + 30;
                 }
                 Console.WriteLine(X);

             }

         }
     }
     */
     /*
        static void Main(string[] args)
        {
            double T;
            Console.WriteLine("T");
            T = double.Parse(Console.ReadLine());
            if (T >= 37.3)
            {
                Console.WriteLine("ALTA");
            }
            else if (T >= 35.4 && T <= 37.2)
            {
                Console.WriteLine("NORMAL");
            }
            else if (T <= 35.3)
            {
                Console.WriteLine("BAIXA");

            }

        }
    }
}
*/

        static void Main(string[] args)
        {
            float i = 1, x;

            Console.WriteLine("digite um número inteiro aleatório: ");

            x = float.Parse(Console.ReadLine());

            while (i >= x)
            {
                Console.WriteLine(i=i+ 9999999999999999999+i+" >> c: ");
            }
            {/*
                 int numero, cont;
            cont = 1;
                 Console.WriteLine("numero");
                 numero = int.Parse(Console.ReadLine());
     /*
                 for(cont=1;cont<=numero;cont++)
                 {
                     Console.WriteLine(cont);
                 }
                 */
            }
        }
    }
}

     /*
        static void Main(string[] args)
        {
            double T;
            Console.WriteLine("T");
            T = double.Parse(Console.ReadLine());
            if (T >= 37.3)
            {
                Console.WriteLine("ALTA");
            }
            else
            {
                if (T >= 35.4 && T <= 37.2)
                {
                    Console.WriteLine("NORMAL");
                }

                else //(T <= 35.3)
                {
                    Console.WriteLine("BAIXA");

                }
            }

        }
    }
}
*/