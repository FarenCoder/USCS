﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Teste1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Este é o meu 1º programa
            //Mostra na tela o meu nome
            Console.WriteLine("Rodolfo Moreno");
            Console.ReadKey();
        }
    }
}
