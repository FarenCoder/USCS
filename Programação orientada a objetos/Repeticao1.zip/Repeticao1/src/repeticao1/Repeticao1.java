/******************************************************************************

Apresentar todos os valores numéricos inteiros impares
situados na faixa de 0 a 20.

*******************************************************************************/

package repeticao1;

public class Repeticao1 {


    public static void main(String[] args) {
           
	for (int i =0; i<20 ; i++ )
	{
	    if (i%2==1) 
	    {
	       System.out.println(i);
	    }
	}          
    }
    
    /*
    public static void main(String[] args) {
        int i= 0;
	   
	while (i<20)
	{
	    if (i%2==1) 
	    {
	       System.out.println(i);
	    }
	    i++;     
	}          
    }
    
    */
}
