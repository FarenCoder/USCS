

package repeticao2;
public class Repeticao2 {

    public static void main(String[] args) {
    	int i;
	int soma = 0;
	   
	for (i=0;i<=100; i++)
	{
	    soma = soma + i;
	}
	System.out.println(soma);		
   }

/*  
    public static void main(String[] args) {
        int i= 0;
        int soma = 0;
	   
        while (i<=100)
        {
            soma = soma + i;
            i++;     
        }
        System.out.println(soma);
    }   
*/    
    
}

