/******************************************************************************
Colocar num vetor os numeros entre 1 e 10 e depois mostrar somente os pares.
*******************************************************************************/

package array2;
public class Array2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	int i;
	int [] v = new int [10];
	   
	   // colocar numeros 1 a 10 em um vetor de 10 posições
	i=0;
	while (i<=9)
	{
	    v[i] = i + 1;
	    i++;     
	}
	   
	   // mostar somente os pares
	for (i=9; i>=0; i--)
	{
	    if (v[i] % 2 ==0)
	    {
	        System.out.println(v[i]);  
	    }
	}  
    }   
}
